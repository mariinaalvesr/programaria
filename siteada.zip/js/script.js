function validaFormulario(){

  if(document.getElementById("nome").value != "" &&
     document.getElementById("email").value != "" &&
     document.getElementById("telefone").value != "" ){

    alert("Prontinho! você receberá as novidades por email.")
  }else{
    alert("Por favor, preencha os campos nome e email.")
  }
}
 






 Uma dica é criar uma cópia do seu projeto no Repl.it para iniciar este novo projeto! Basta ir no menu de projetos: My Repls> clicar nos três pontinhos do seu projeto> escolher a opção Fork do menu para fazer essa experimentação! Fork é criar uma cópia do seu repositório! 